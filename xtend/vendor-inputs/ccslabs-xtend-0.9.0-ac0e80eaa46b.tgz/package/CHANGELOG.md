# Changelog

Alle sichtbaren Produktaenderungen werden in diesem Dokument gesammelt. XTend ist fuer RC1-Publish-Prep auf `private: false` geoeffnet; der eigentliche Publish-Befehl bleibt ein separater manueller Owner-Schritt.

## Unreleased

## 0.9.0 - 2026-10-03

- Renderer v2 behandelt Attributstrings literal; portable v1 und alte Seitenverträge bleiben mindestens in 0.9/0.10 unterstützt. Entfernung frühestens mit 1.0 nach Migration.
- SSR-Coverage liegt als eigener Vertrag in Telemetry; initiale Node-/Laravel-Resume-Dokumente verwenden einen eigenen Descriptor-Transport bei unveränderten Signaturen und vollständigen Page-API-Antworten.
- Kernel-/MCP-Artefakte, Schema-Inventar und Release-Versionen sind abgestimmt. Atomare MCP-Reparaturen erhalten Dateimodi auch bei restriktiver umask.
- Nightly umfasst verpflichtende Legacy-/Canonical-, PHP-/Laravel-12/13-, Resume-/Browser- und XTensions-Host-Prüfungen.

- Docs Shell: Sprachwechsel aktualisieren den gemeinsamen Locale-Service vor Suche und Navigation. Der gemeinsame FastPass-Validator verwendet Syntax, die auch der ältere Docs-Bridge-Host parsen kann.

- Docs: Die [deutsche](./docs/de/changelog.md) und [englische](./docs/en/changelog.md) 0.8.0-Übersicht dokumentieren auch die seit dem Kernel-Stand vom 30. August ergänzten Funktionen; Navigation, Suche und MCP-Wissen werden daraus generiert.
- Hydrangea JIT: opt-in `jit-compile` bündelt Compile, Safe Preview und optionale Maraca-Vorbereitung in einem Node-Prozess. Der private Cache hält verifizierte Framework-Artefakte; `legacy` bleibt der Standard. Der Playground koordiniert aktuelle Requests und verwirft veraltete Antworten unabhängig vom Backend.
- Seitenlaufzeit: unabhängige Node- und Laravel-Hosts, gemeinsame Page-Contracts, kompakter `xtend.page-wire.v1`-Transport und aktive bedingte Ansichten; XTend.store demonstriert resumable Maraca-Seiten mit Laravel und separatem DemoPay-Provider.
- Overlay-Fokusfallen berücksichtigen geslottete und Remote-Controls. Tooling-/Nightly-Verifikation verwendet den gemeinsamen Katalog mit expliziter Capability- und Artefakt-Evidence.

- RMT Scheduler: Paint-, Idle- und postTask-Wartephasen geben die Scheduler-Autorität frei; Cancellation, Host-Fehler und kooperative Fortsetzungen bleiben geschützt.
- Maraca: Vollsnapshots entstehen automatisch nur bei Vollsnapshot-Abonnements. `subscribeEvents()` ergänzt schlanke Lifecycle-Signale; DEV-Einzelabrufe bleiben aktuell.
- Maraca FastPass: `execution fastpass`, `fastPassActions` und `dispatchFastPass()` priorisieren validierte Navigation-, Fokus- und Close-Intents über dieselbe `user-blocking`-Lane, mit Schutz vor verspäteten Präsentations-Commits.
- Abort Boundary: Verwaltete Surface-Epochen, Worker-Abbruchsignale und Commit-Guards verhindern veraltete Hydration und Ressourceninitialisierung. Externe Renderer erhalten denselben Vertrag über `createMaracaAbortBoundary()`.

- Release-Verträge: Plan-Runtime v3, Presentation-Adapter v2 und ein separates FastPass-Schema; bestehende Methoden bleiben verfügbar. Die Typvorlage enthält keine selbstreferenzierenden Alias-Duplikate mehr.

- RMT: Delegierte UI-Ereignisse und Commands werfen beim Aufbau ihres Handler-Kontexts keinen `ReferenceError` mehr. `ctx.scheduler.getPriorityQueueStats()` liest den aktuellen Snapshot der injizierten Kernel-Scheduler-Instanz; ein Regressionstest deckt die Modulquelle sowie Core-, ESM- und Browser-Artefakte ab.

## 0.8.0 - 2026-08-30

- Release-Konsistenz: XTM-Peer-Vertrag und XTensions-Kompatibilitätsdefault folgen der 0.8.0-Release-Linie. Ein unreferenziertes 0.7.0-Kernel-Artefakt der Docs-Shell wird nicht mehr mit ausgeliefert; eigenständig versionierte XTM-, MCP- und Editor-Pakete behalten ihre Versionslinien.
- Breaking: `@ccslabs/xtend/rmt/kernel-scheduler` und `@ccslabs/xtend-rmt/kernel-scheduler` liefern den hostneutralen Microkernel mit einem thenable `RmtJobHandle`; `await handle` ergibt direkt das Arbeitsergebnis.
- Der Kernel ist die einzige Scheduler-Autoritaet. Fabric uebergibt Work-Intents und Backpressure, besitzt aber keine eigene Queue; Registry, Maraca, Core, Browser Runtime und State-/Telemetry-Bridge verwenden dieselbe injizierte Scheduler-Instanz.
- Die kanonischen Lanes sind `user-blocking`, `visible`, `transition`, `idle`, `background` und `diagnostics`. Alte Kernel-Lanes werden nur noch vom Browser-Migrationsadapter normalisiert.
- `inline` und `runInline` umgehen die Queue nicht mehr. Strict Mode lehnt sie ab, der nicht-strikte Modus plant sie mit Migrationsdiagnose regulaer ein.
- Product Surface ist ein expliziter Opt-in-Service. ESM-Importe booten keine Runtime und schreiben kein globales `AppModules`-Mirror.
- Die 0.7-Kompatibilitaetsschichten und abgelaufenen `removeBy: 0.7.0`-Ausnahmen wurden entfernt. Prewarm bleibt standardmaessig aus; Retained Chunks sind auf 32 Eintraege und zwei Generationen pro Scope begrenzt.
- KernelLab prueft das eigenstaendige Microkernel-Artefakt, Runtime-Port-Provider, Service-Importverbote, Zyklen, Duplikate, Bundle-Budgets und abgelaufene Compatibility-Eintraege.
- Migration: `docs/de/rmt-kernel-0-8-migration.md` und `docs/en/rmt-kernel-0-8-migration.md`. Es erfolgt kein automatischer Publish.

## 0.6.1 - 2026-08-10

- Der moderne Maraca-Pfad nutzt einen atomaren RMT-Model-Command-Port und veröffentlicht pro Kommando nur abgeschlossene Model-, Selector- und Derived-Snapshots.
- DOM-, Event-, Validation-, Transition-, Presentation- und Surface-Projektionen sind über explizite Ports vom Application Controller getrennt; Legacy-Zugriffe bleiben diagnostizierte 0.6-Kompatibilitätsfassaden.
- Der Surface Controller ist alleinige Lifecycle-Autorität und projiziert atomare Lifecycle-Operationen in Resource Graph, Portal- und Overlay-Handles.
- KernelLab baut ESM-, Browser-, Typ-, Schema- und Manifest-Artefakte ausschließlich aus kanonischen Modulquellen und blockiert MVC-Verstöße, nicht deklarierte Abhängigkeiten sowie Legacy-Bundle-Eingaben.
- State Binding wurde in ein reines Model und einen eigenständigen View-Projektor getrennt; die bisherige gemischte API lebt nur in einer Compatibility-Composition-Fassade weiter.
- Die geänderten Runtime-Verträge werden als neue v2-Schemafamilien geführt; das Schema-Gate schützt veröffentlichte Fingerprints und reserviert abgelöste v1-IDs als Tombstones.
- Nightly-Manifest, verpflichtende Build-Reports und gesplittete Resume-Module wurden an die produktiven Workflows angeglichen.

## 0.5.0 - 2026-07-19

- Stage-A-Node-Matrix fuer CI, Nightly und native Produkt-Smokes eingefuehrt: `24.18.0` ist die primaere Runtime, `26.5.0` die verpflichtende Current-Lane, npm ist auf `11.17.0` gepinnt und jede Lane liefert eigene Runtime-Evidence sowie Artefakte nach `{artifactSuffix}` beziehungsweise `${{ matrix.artifact_suffix }}`. Der manuell freigegebene npm-Publish bleibt auf Node `24.18.0` und `xtend-npm-publish-latest-evidence-node-24-18-0` begrenzt.
- Breaking: Der Root-Import `@ccslabs/xtend` ist jetzt eine ESM-Registry mit kompakten Scheduling-, Rendering-, State- und Runtime-Aliasen sowie einem SSR-sicheren Einstieg. XTend Classic bleibt unter `@ccslabs/xtend/loader` verfügbar; die veraltete generierte `xtend.js`-Komponentenimplementierung wurde entfernt.
- TypeScript-DX der ESM-Registry um opt-in App-/Store-Generics, geprüfte DOM-Descriptoren, einen DOM-neutralen NodeNext-Typvertrag und eine Vite-basierte TS-App-Demo erweitert.
- XTend Material als `supported-opt-in` Fast Path dokumentiert: zweisprachiger Quick Start, bidirektionale Migration, Compatibility Matrix, SemVer Policy, Package-Changelogs und Tailwind-Upgrade-Runbook ergänzen die XTM-00-bis-XTM-12-Evidence; ein Framework-Default bleibt ohne separaten ADR ausgeschlossen.
- Maraca AppServices als kanonische RMT-/Business-Logic-Grenze ergänzt: generierte `services.ts`-/Node-/PHP-Ziele, striktes TypeScript-Program-Typechecking, getrennte Rollup-Graphen, versioniertes JSON/NDJSON, zentrale Abort-/Concurrency-/Stream-Semantik, Service-Manifeste und getrennte App-/Framework-Budgets.
- XScaler als öffentliche, typisierte `@ccslabs/xtend/xscaler`-API mit JSON-Schemas, PHP-Preflight-Parität, SRI-/CSP-konformem Remote-Adapter-Loader, ATC-Lifecycle und SSR-Preflight-only-Hydration stabilisiert; XSurface Shard verwendet denselben öffentlichen Vertrag.
- Provider-neutralen RMT-App-Scaffold samt XTM-Overlay und XTend-LLM-Catfood-Migration ergänzt; neue Apps benötigen kein manuelles Maraca-Boot-/DOM-/Adapter-Wiring und bestehende Adapter bleiben über den diagnostizierten Compatibility-Modus nutzbar.
- SchemaDB v2 ergaenzt authoritative Fingerprints, Versionsfamilien, Lifecycle-, Alias- und Konsolidierungsentscheidungen sowie einen maschinenlesbaren Dubletten-Audit.
- Die identischen Chart-, Leaflet-, React-, Three- und Vue-Cleanup-Records werden unter `xtend.xtensions.host-resource-cleanup-record.v1` gebuendelt. Die bisherigen IDs bleiben fuer zwei Minor-Warnfenster als exakte Aliase lesbar; ihre Entfernung ist fruehestens in einem folgenden Major erlaubt.
- `xtend.xtensions.host-controller-cleanup-record.v1` bleibt als separater sechs-feldriger Vertrag ohne `xtensionId` bestehen.

## 0.1.0-rc.1 Test-Build - 2026-05-16

- Ersten lokalen RC1-Test-Build-Schnitt unter `xtend.rc1.test-build-handoff.v1` dokumentiert.
- Handoff in `development/XTend-RC1-Test-Build-Handoff.md` mit Datum, Commit-Basis `4e0ae07`, Gate-Reports, Pack Dry Run Evidence und offenen Owner-Entscheidungen ergaenzt.
- RMT vNext Reference Demo und XTendRMT Bestcase Demo als Test-Build-Referenzpfade aufgenommen.
- RC1-Publish-Prep ist auf Version `0.1.0-rc.1` umgestellt: `package.json`, `package-lock.json` und die XTendRMT VS-Code-Bridge tragen die RC-Version; `private: false` ist gesetzt, `npm publish` wurde noch nicht ausgefuehrt.
- Netzwerkpflichtige Audit-/SBOM-Evidence im Owner-Publish-Schritt ausgefuehrt und akzeptiert: Audit meldet 0 Vulnerabilities, SBOM liegt als CycloneDX `1.5` mit `Apache-2.0` License Evidence vor.
- Release Owner Test-Build Acceptance unter `xtend.rc1.test-build-owner-acceptance.v1` dokumentiert: interne Testnutzung akzeptiert, `npm publish` und automatische Publish-Freigaben bleiben blockiert.
- Separaten Owner-Publish-Entscheid unter `xtend.rc1.release-owner-publish-decision.v1` auf `accepted-for-publish-prep` gestellt; Version, License, Audit/SBOM und Package Boundary sind akzeptiert, der eigentliche Publish-Befehl bleibt manuell.
- Apache License 2.0 als Projektlizenz fuer den kompletten XTend-Stack gesetzt: Root-Manifest, XTendRMT VS-Code-Bridge, `LICENSE`, Supply-Chain-Policy und Owner-Publish-Decision sind auf `Apache-2.0` aktualisiert.
- Scoped Release-Matrix ergaenzt: Root-Package `@ccslabs/xtend` sowie Teilpakete `@ccslabs/xtend-rmt`, `@ccslabs/xtend-fabric`, `@ccslabs/xtend-cli` und `@ccslabs/xtend-compiler` sind ueber Root-Workspaces und untergeordnete Manifests abgebildet.
- RMT Node SSR Adapter unter `xtend.rmt.node-ssr-adapter.v1` ergaenzt: `./rmt/node-ssr-adapter` und `@ccslabs/xtend-rmt/node-ssr-adapter` liefern Light-DOM-SSR, Hydration-Payloads, JSONL-Streaming und explizite DataSource-/Trust-Boundary-Diagnostics.
- RMT PHP/Laravel SSR Adapter unter `xtend.rmt.php-ssr-adapter.v1` ergaenzt: `xtendrmt/rmt-php-ssr-adapter.php` liefert denselben Client-Wire-Shape wie der Node Adapter, inklusive RMT-Chunks, Hydration-Payloads, JSONL-Streaming, Laravel Response Helpers und `rmt.php_ssr.*` Diagnostics.

## Enterprise-Readiness Baseline - 2026-05-06

- Package-Export-Strategie unter `xtend.package-export.release-strategy.v1` vorbereitet.
- Kanonische Package-Subpaths fuer Loader, API, Komponentenmanifest, Fabric, Fabric/RMT Lane Mapping, XTendRMT Runtime und Scaffold CLI festgelegt.
- Release-Gates `release:check`, `release:report` und `pack:dry-run` in `package.json` ergaenzt.
- Supply-Chain-Gate-Plan unter `xtend.security.supply-chain-gate-plan.v1` mit Offline-Verify, License Policy, Vulnerability Policy und CI-Audit-Handoff ergaenzt.
- Lokale Gates `test:supply-chain` und `supply-chain:verify` ergaenzt.
- Performance Measurements unter `xtend.performance.measurement.v1` fuer Loader, Hydration, Render und Route Render ergaenzt.
- Lokales Gate `test:fabric-performance` ergaenzt.
- Performance Regression Gate unter `xtend.performance.regression-gate.v1` mit deterministischer Baseline und `test:performance` ergaenzt.
- Hydration Policies unter `xtend.fabric.hydration-policy.v1` fuer visible, idle und lazy Hydration mit `test:hydration-policy` ergaenzt.
- Performance-Autorendoku und Scaffold Policy `xtend.scaffold.performance-policy.v1` fuer Component-Profile ergaenzt.
- Browsernahe A11y-Fokus-/Keyboard-Smokes unter `xtend.a11y.browser-keyboard-smoke.v1` fuer Routing, Overlay, Form/Input und Tabs ergaenzt.
- Screenreader-Signal-Contracts unter `xtend.a11y.screenreader-signals.v1` fuer `aria-live`, Statusregionen, Errorregionen und Announcements mit `test:screenreader-signals` ergaenzt.
- Motion-/Contrast-Policy unter `xtend.a11y.motion-contrast-policy.v1` fuer `prefers-reduced-motion`, `forced-colors`, Fokus und Nicht-Farbstatus mit `test:motion-contrast` ergaenzt.
- Manifest-/Dynamic-Import-Policy unter `xtend.security.manifest-import-gate.v1` mit Loader-Refusals und lokalem Gate ergaenzt.
- Component Catalog Coverage Matrix unter `xtend.catalog.component-coverage-matrix.v1` mit `test:catalog-coverage`, Package-Export und Handoff an Catalog-Folgepakete ergaenzt.
- Visual-/Browser-Regression-Prioritaetsplan unter `xtend.catalog.component-regression-priority-plan.v1` mit `test:regression-priority`, Package-Export und CI-Handoff ergaenzt.
- CI Default Gates unter `xtend.ci.default-gates.v1` mit GitHub-Actions-Workflow, Node `26.x`, `npm run test:report` und Artifact `xtend-test-report-node-26` ergaenzt.
- CI Gate Matrix unter `xtend.ci.gate-matrix.v1` mit `test:pr`, `test:pr:report`, `test:release:full`, `test:release:full:report`, PR-Fast-Artifact und Full-Release-Artifact ergaenzt.
- Release Checklist und SemVer Policy unter `xtend.release.checklist-semver-policy.v1` mit `xtend.releaseChecklist`, Candidate Gates, Conditional Network Gates, Breaking-Change-Pflichten, Migration Notes, Artifact-Checklist und Release-Owner-Publish-Boundary ergaenzt.
- Enterprise Adoption Guide unter `xtend.docs.enterprise-adoption.v1` mit `xtend.enterpriseAdoption`, Loader-, Fabric-, RMT-, Security-, A11y-, Performance-, CI- und Release-Readiness-Pfad ergaenzt.
- RC0 Gate Matrix und RC0 Adoption Guide unter `xtend.epic12.rc0-gate-matrix.v1` und `xtend.epic12.docs-adoption.v1` mit `test:rc0-gate-matrix`, `test:epic12-docs-adoption`, Migration Notes, Known Residual Policy und Publish Boundary ergaenzt.
- Epic 12 RC0 Handoff unter `xtend.epic12.rc0-handoff.v1` mit `test:epic12-rc0-handoff`, Owner Review Inputs, Conditional Network Gate Status, Known Residual Policy und Status `ready-for-release-owner-review-not-publish` ergaenzt.
- Epic 13 RC1 Readiness Model unter `xtend.epic13.rc1-production-readiness.v1` mit `test:epic13-rc1-readiness`, RC0-zu-RC1-Gate-Abgleich, Feature-Drift-Bereinigung und Workpackages fuer Production Readiness vorbereitet.
- Epic 13 Release Owner Acceptance Contract unter `xtend.epic13.release-owner-acceptance.v1` mit `test:epic13-release-owner-acceptance`, Owner Checklist, `accepted`/`deferred`/`blocked` Statuswerten, blockierter `automatic-publish-approval` und Handoff an `WP-E13-03` ergaenzt.
- Epic 13 Conditional Network Evidence unter `xtend.epic13.conditional-network-evidence.v1` mit `test:epic13-conditional-network-evidence`, Audit-/SBOM-Artefaktpfaden, `xtend.epic13.conditional-network-deferral.v1` und lokal netzwerkfreiem Owner-Deferral-Modell ergaenzt.
- Epic 13 Package Export Lock unter `xtend.epic13.package-export-lock.v1` mit `test:epic13-package-export-lock`, `pack:dry-run:report`, `.xtend-test-results/xtend-pack-dry-run.json`, `.xtend-test-results/xtend-package-export-surface-lock.json` und Drift-Check gegen `package.json#exports` ergaenzt.
- Epic 13 Known Residual Triage unter `xtend.epic13.known-residual-triage.v1` mit `test:epic13-known-residual-triage`, Boundary-Schliessungen fuer `xstate`/`x-utils` und `xtend.component.hydrate` als WP-E13-06 Watchpoint ergaenzt.
- Epic 13 Hydration Performance Closure unter `xtend.epic13.hydration-performance-closure.v1` mit `test:epic13-hydration-performance-closure`, `xtend.component.hydrate` bei `31ms / 32ms`, `warnCount === 0` und Handoff nach `WP-E13-09` ergaenzt.
- Epic 13 PROD Browser CSP Smoke unter `xtend.epic13.prod-browser-csp-smoke.v1` mit `test:epic13-prod-browser-csp-smoke`, `dev:local:csp`, Nonce, same-origin Manifest, lokalem CSP Header und `tests/browser/fixtures/epic13-prod-csp-smoke.html` ergaenzt.
- Epic 13 Visual Owner Artifact unter `xtend.epic13.visual-owner-artifact.v1` mit `test:epic13-visual-owner-artifact`, Manifest `tests/browser/visual-baselines/rc1-visual-owner-artifact.manifest.json`, deterministischen Viewports und optionalem Screenshot-/Pixel-Artefaktpfad ergaenzt.
- Epic 13 RMT Production Readiness unter `xtend.epic13.rmt-production-readiness.v1` mit `test:epic13-rmt-production-readiness`, RMT-first App Shell, Routing, Components, Fabric/Lanes, Lifecycle Telemetry, Diagnostics und Artifact Parity als RC1-Buendel ergaenzt.
- Epic 13 Docs RMT Production Hardening unter `xtend.epic13.docs-rmt-production-hardening.v1` mit `test:epic13-docs-rmt-production-hardening`, stabilen Docs-App Extension-Slots, Parsedown-Host-Boundary, Rich-HTML-/XPlayer-Schedules und Diagnostics ergaenzt.
- Epic 13 Trusted DOM Boundary unter `xtend.epic13.trusted-dom-boundary.v1` mit `test:epic13-trusted-dom-boundary`, Sanitizer `xtend.security.trusted-dom-sanitizer.v1`, browsernaher Fixture `tests/browser/fixtures/epic13-trusted-dom-boundary-smoke.html` und Package-Metadaten `xtend.epic13TrustedDomBoundary` ergaenzt.
- Epic 13 RC1 Migration Notes unter `xtend.epic13.rc1-migration-notes-semver.v1` mit `test:epic13-rc1-migration-notes`, vorgeschlagener Version `0.1.0-rc.1`, Migration Notes, SemVer Decision, Changelog-Pflichten und Package-Metadaten `xtend.epic13Rc1MigrationNotes` ergaenzt.
- Epic 13 RC1 Gate Matrix und CI-Handoff unter `xtend.epic13.rc1-gate-matrix-ci-handoff.v1` mit `test:epic13-rc1-gate-matrix-ci-handoff`, CI Lanes, Report-Artefakten, Referenzpfaden und Package-Metadaten `xtend.epic13Rc1GateMatrixCiHandoff` ergaenzt.
- Release Report und Pack Dry Run Evidence unter `xtend.epic13.release-report-pack-dry-run-evidence.v1` mit `test:epic13-release-report-pack-dry-run-evidence`, reproduzierbaren Owner-Artefakten, `pack:dry-run` Capture-Pfad und Package-Metadaten `xtend.epic13ReleaseReportPackDryRunEvidence` ergaenzt.
- Conditional Network Evidence CI unter `xtend.epic13.conditional-network-evidence-ci.v1` mit `test:epic13-conditional-network-evidence-ci`, `conditional-network:evidence`, CI-Upload-Artefakten und Package-Metadaten `xtend.epic13ConditionalNetworkEvidenceCi` ergaenzt.
- Docs-App RMT Parsedown Scheduling Pilot unter `xtend.docs.parsedown-rmt-pilot.v1` auf Shell-first erweitert: `docs.app.shell`, `docs.header.search`, `docs.media.lazy`, `xtend.docsRmtPilot`, `docs/xtendrmt-parsedown-docs.rmt`, per-page Host-Metadaten und `test:docs-rmt-pilot` sind gatebar.
- Docs-App UX-Hardening fuer `x-header`/`x-hero` ergaenzt: strukturierte Docs-Navigation, `search`-/`actions`-Slotmodell, kontraststarke Header-Shell, themenfaehiger Hero und leichte Route-Mikrointeraktionen ohne Docs-App-Monkeypatching.
- XRouter Scroll-Boundary-Normalisierung unter `xtend.router.scroll-boundary.v1` ergaenzt, damit Route-Wechsel von langen auf kurze Seiten keine stale Scrollpositionen oder Deadzones unterhalb des Contentbereichs hinterlassen.
- Form-Control-Shell-Sizing fuer `x-form` und `x-input` gehaertet, damit Header-Suchen und kompakte Form-Slots Padding, Border und Control-Breite ohne horizontales Herausragen berechnen.
- Header-Navigation als fixed Full-Width-Overlay gehaertet und XRouter Overlay-Cleanup unter `xtend.router.closedNavigationOverlays` ergaenzt, damit geoeffnete Menues beim Route-Wechsel keine Deadzones oder lange Scrollbereiche erzeugen.
- Docs-App Parsedown SafeMode-Nachbearbeitung fuer Inline-Code ergaenzt, damit Komponenten-Namen wie `<x-code>` nicht als doppelt escapete Entities angezeigt werden und die Trusted-DOM-Boundary trotzdem erhalten bleibt.
- Docs-App Navigation von flacher Linkliste auf kaskadierende Artikelhierarchie mit `id`, `group`, `parent`, `tier` und PageRank-artigem `rank` umgestellt, sodass Basics zuerst sichtbar sind und Spezialthemen als Deep Dives aufklappen.
- `x-icon` als RMT-kompatible XTend-Komponente ergaenzt: lokale Core-Icons, lokaler Lucide-Adapter, globale `window.XTend.icons` Registry, Public Types, Component-Suite, Fixture und Docs-App-Menue-Ikonographie ohne CDN-Abhaengigkeit.
- npm Provenance fuer spaetere Releases vorbereitet.
- Root-README fuer Package-Konsumenten und lokale Enterprise-Entwicklung ergaenzt.
