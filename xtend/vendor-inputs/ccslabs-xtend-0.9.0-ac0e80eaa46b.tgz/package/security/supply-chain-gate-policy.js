const SUPPLY_CHAIN_GATE_PLAN_CONTRACT = 'xtend.security.supply-chain-gate-plan.v1';
const DEPENDENCY_AUDIT_GATE_CONTRACT = 'xtend.security.dependency-audit-gate.v1';
const LICENSE_POLICY_CONTRACT = 'xtend.security.license-policy.v1';
const VULNERABILITY_POLICY_CONTRACT = 'xtend.security.vulnerability-policy.v1';
const RELEASE_SUPPLY_CHAIN_GATE_CONTRACT = 'xtend.security.release-supply-chain-gate.v1';

const DEPENDENCY_SECTIONS = [
  'dependencies',
  'devDependencies',
  'optionalDependencies',
  'peerDependencies'
];

const LOCKFILE_CANDIDATES = [
  'package-lock.json',
  'npm-shrinkwrap.json',
  'pnpm-lock.yaml',
  'yarn.lock'
];

const ALLOWED_DEV_TOOLING_DEPENDENCIES = Object.freeze([
  {
    name: 'acorn',
    section: 'devDependencies',
    versionRange: '8.18.0',
    purpose: 'vendored-xscaler-import-graph-verifier',
    runtime: false
  },
  {
    name: '@types/node',
    section: 'devDependencies',
    versionRange: '^24.13.3',
    purpose: 'minimum-supported-node-type-contract',
    runtime: false
  },
  {
    name: 'typescript',
    section: 'devDependencies',
    versionRange: '^5.9.3',
    purpose: 'component-typescript-compiler',
    runtime: false
  },
  {
    name: 'esbuild',
    section: 'devDependencies',
    versionRange: '^0.28.2',
    purpose: 'native-toolchain-and-ssr-resource-tests',
    runtime: false
  },
  {
    name: 'vite',
    section: 'devDependencies',
    versionRange: '^8.3.3',
    purpose: 'typescript-demo-and-dev-hmr-spike-only',
    runtime: false
  }
]);

// Reviewed exceptions for the parser-based sanitizer. All other new runtime
// dependencies remain forbidden, and these exact versions require a lockfile.
const ALLOWED_SECURITY_RUNTIME_DEPENDENCIES = Object.freeze([
  {name: 'jsdom', section: 'dependencies', versionRange: '30.1.2', purpose: 'node-html-sanitizer-parser', runtime: true},
  {name: 'dompurify', section: 'dependencies', versionRange: '3.4.16', purpose: 'shared-html-sanitizer', runtime: true}
]);

const SCOPED_RELEASE_PACKAGES = Object.freeze([
  {
    name: '@ccslabs/xtend',
    path: '.',
    manifest: 'package.json',
    scope: 'complete-stack'
  },
  {
    name: '@ccslabs/xtend-rmt',
    path: 'xtendrmt',
    manifest: 'xtendrmt/package.json',
    scope: 'rmt-runtime'
  },
  {
    name: '@ccslabs/xtend-fabric',
    path: 'fabric',
    manifest: 'fabric/package.json',
    scope: 'fabric-runtime'
  },
  {
    name: '@ccslabs/xtend-cli',
    path: 'xtend-builder',
    manifest: 'xtend-builder/package.json',
    scope: 'builder-cli'
  },
  {
    name: '@ccslabs/xtend-compiler',
    path: 'tools',
    manifest: 'tools/package.json',
    scope: 'rmt-compiler-tooling'
  },
  {
    name: '@ccslabs/xtend-maraca',
    path: 'xtend-maraca',
    manifest: 'xtend-maraca/package.json',
    scope: 'maraca-bundler'
  },
  {
    name: '@ccslabs/xtend-xsurface-shard',
    path: 'xsurface-shard',
    manifest: 'xsurface-shard/package.json',
    scope: 'remote-surface-runtime'
  }
]);

const LICENSE_POLICY = {
  currentPackageLicense: 'Apache-2.0',
  projectLicenseDecision: 'accepted-apache-2.0',
  privatePackageAllowedLicenses: ['Apache-2.0'],
  publicReleaseRequiresLicenseDecision: false,
  publicReleaseLicenseDecision: 'accepted-apache-2.0',
  allowedDependencyLicenses: [
    'Apache-2.0',
    'BSD-2-Clause',
    'BSD-3-Clause',
    'ISC',
    'MIT',
    'MPL-2.0',
    'Unicode-DFS-2016'
  ],
  reviewRequiredLicenses: [
    'BlueOak-1.0.0',
    'CC-BY-4.0',
    'CC0-1.0',
    'LGPL-2.1-only',
    'LGPL-2.1-or-later',
    'LGPL-3.0-only',
    'LGPL-3.0-or-later'
  ],
  forbiddenDependencyLicenses: [
    'AGPL-1.0-only',
    'AGPL-1.0-or-later',
    'AGPL-3.0-only',
    'AGPL-3.0-or-later',
    'GPL-2.0-only',
    'GPL-2.0-or-later',
    'GPL-3.0-only',
    'GPL-3.0-or-later',
    'UNLICENSED'
  ]
};

const VULNERABILITY_POLICY = {
  productionAuditLevel: 'moderate',
  developmentAuditLevel: 'high',
  publishBlockingSeverities: ['critical', 'high'],
  zeroCriticalForAnyRelease: true,
  noKnownExploitForReleaseCandidate: true,
  networkAuditStage: 'ci-release-gate',
  localGateMode: 'offline-policy-and-inventory'
};

const SUPPLY_CHAIN_GATES = [
  {
    id: 'dependency-inventory',
    contract: DEPENDENCY_AUDIT_GATE_CONTRACT,
    stage: 'local',
    command: 'node scripts/verify_supply_chain_policy.js --json',
    mode: 'offline-static',
    blocksPublish: true
  },
  {
    id: 'license-policy',
    contract: LICENSE_POLICY_CONTRACT,
    stage: 'local',
    command: 'node scripts/verify_supply_chain_policy.js --json',
    mode: 'offline-static',
    blocksPublish: true
  },
  {
    id: 'vulnerability-policy',
    contract: VULNERABILITY_POLICY_CONTRACT,
    stage: 'ci',
    command: 'npm audit --audit-level=moderate',
    mode: 'network-audit',
    blocksPublish: true
  },
  {
    id: 'release-report',
    contract: RELEASE_SUPPLY_CHAIN_GATE_CONTRACT,
    stage: 'local',
    command: 'npm run release:report',
    mode: 'offline-test-report',
    blocksPublish: true
  },
  {
    id: 'pack-provenance-dry-run',
    contract: RELEASE_SUPPLY_CHAIN_GATE_CONTRACT,
    stage: 'local',
    command: 'npm run pack:dry-run',
    mode: 'offline-package-surface',
    blocksPublish: true
  }
];

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function listDependencies(packageManifest = {}) {
  return DEPENDENCY_SECTIONS.flatMap((section) => {
    const entries = packageManifest[section] && typeof packageManifest[section] === 'object'
      ? Object.entries(packageManifest[section])
      : [];

    return entries.map(([name, version]) => ({
      name,
      version,
      section
    }));
  });
}

function createSupplyChainGatePlan(options = {}) {
  return {
    schema: SUPPLY_CHAIN_GATE_PLAN_CONTRACT,
    dependencyAuditGate: DEPENDENCY_AUDIT_GATE_CONTRACT,
    licensePolicy: LICENSE_POLICY_CONTRACT,
    vulnerabilityPolicy: VULNERABILITY_POLICY_CONTRACT,
    releaseGate: RELEASE_SUPPLY_CHAIN_GATE_CONTRACT,
    mode: options.mode || 'plan-and-offline-local-gate',
    localGate: 'node scripts/verify_supply_chain_policy.js --json',
    packageScript: 'npm run test:supply-chain',
    releaseScripts: [
      'npm test',
      'npm run test:supply-chain',
      'npm run release:report',
      'npm run pack:dry-run'
    ],
    ciNetworkGates: [
      'npm audit --audit-level=moderate',
      'npm sbom --sbom-format=cyclonedx --json --package-lock-only'
    ],
    gates: clone(SUPPLY_CHAIN_GATES),
    dependencySections: clone(DEPENDENCY_SECTIONS),
    lockfileCandidates: clone(LOCKFILE_CANDIDATES),
    scopedReleasePackages: clone(SCOPED_RELEASE_PACKAGES),
    allowedDevToolingDependencies: clone(ALLOWED_DEV_TOOLING_DEPENDENCIES),
    allowedSecurityRuntimeDependencies: clone(ALLOWED_SECURITY_RUNTIME_DEPENDENCIES),
    license: clone(LICENSE_POLICY),
    vulnerabilities: clone(VULNERABILITY_POLICY),
    runtimeDependencyPolicy: 'no-new-runtime-dependencies',
    publishBoundary: {
      privateUntil: ['ER-WP-30', 'ER-WP-36', 'ER-WP-38'],
      currentPublishState: 'owner-approved-public-rc-boundary',
      provenanceRequired: true,
      publicReleaseRequiresLicenseDecision: false,
      licenseDecision: 'accepted-apache-2.0'
    }
  };
}

function classifyPackageSupplyChain(packageManifest = {}, lockfiles = []) {
  const dependencies = listDependencies(packageManifest);
  const hasDependencies = dependencies.length > 0;
  const hasLockfile = Array.isArray(lockfiles) && lockfiles.length > 0;
  const allowedDevToolingDependencies = dependencies.filter((dependency) => (
    ALLOWED_DEV_TOOLING_DEPENDENCIES.some((allowed) => (
      allowed.name === dependency.name
        && allowed.section === dependency.section
        && dependency.version === allowed.versionRange
    ))
  ));
  const runtimeDependencies = dependencies.filter((dependency) => (
    dependency.section === 'dependencies'
      || dependency.section === 'optionalDependencies'
      || dependency.section === 'peerDependencies'
  ));
  const allowedSecurityRuntimeDependencies = runtimeDependencies.filter(dependency =>
    ALLOWED_SECURITY_RUNTIME_DEPENDENCIES.some(allowed => allowed.name === dependency.name && allowed.section === dependency.section && allowed.versionRange === dependency.version)
  );
  const unapprovedRuntimeDependencies = runtimeDependencies.filter(dependency => !allowedSecurityRuntimeDependencies.includes(dependency));
  const unapprovedDependencies = dependencies.filter((dependency) => (
    ![...allowedDevToolingDependencies, ...allowedSecurityRuntimeDependencies].some((allowedDependency) => (
      allowedDependency.name === dependency.name
        && allowedDependency.section === dependency.section
    ))
  ));
  const diagnostics = [];

  if ((unapprovedDependencies.length > 0 || allowedSecurityRuntimeDependencies.length > 0) && !hasLockfile) {
    diagnostics.push('xtend.security.supply_chain.lockfile.missing');
  }

  if (unapprovedRuntimeDependencies.length > 0) {
    diagnostics.push('xtend.security.supply_chain.runtime_dependency.present');
  }

  if (unapprovedDependencies.length > 0) {
    diagnostics.push('xtend.security.supply_chain.dependency.unapproved');
  }

  if (packageManifest.private !== false) {
    diagnostics.push('xtend.security.supply_chain.private_boundary.missing');
  }

  if (packageManifest.license === 'UNLICENSED' && packageManifest.private !== true) {
    diagnostics.push('xtend.security.supply_chain.public_license.missing');
  }

  if (!packageManifest.publishConfig || packageManifest.publishConfig.provenance !== true) {
    diagnostics.push('xtend.security.supply_chain.provenance.missing');
  }

  return {
    schema: DEPENDENCY_AUDIT_GATE_CONTRACT,
    ok: diagnostics.length === 0,
    dependencyCount: dependencies.length,
    dependencies,
    runtimeDependencyCount: runtimeDependencies.length,
    runtimeDependencies,
    allowedSecurityRuntimeDependencies,
    unapprovedRuntimeDependencies,
    devToolingDependencyCount: allowedDevToolingDependencies.length,
    allowedDevToolingDependencies,
    unapprovedDependencies,
    lockfiles,
    hasLockfile,
    privatePackage: packageManifest.private === true,
    publicRcPackage: packageManifest.private === false,
    packageLicense: packageManifest.license || null,
    diagnostics
  };
}

module.exports = {
  ALLOWED_DEV_TOOLING_DEPENDENCIES,
  ALLOWED_SECURITY_RUNTIME_DEPENDENCIES,
  DEPENDENCY_AUDIT_GATE_CONTRACT,
  DEPENDENCY_SECTIONS,
  LICENSE_POLICY,
  LICENSE_POLICY_CONTRACT,
  LOCKFILE_CANDIDATES,
  SCOPED_RELEASE_PACKAGES,
  RELEASE_SUPPLY_CHAIN_GATE_CONTRACT,
  SUPPLY_CHAIN_GATE_PLAN_CONTRACT,
  SUPPLY_CHAIN_GATES,
  VULNERABILITY_POLICY,
  VULNERABILITY_POLICY_CONTRACT,
  classifyPackageSupplyChain,
  createSupplyChainGatePlan,
  listDependencies
};
