'use strict';

const XSCALER_PREFLIGHT_REQUEST_SCHEMA = 'xtend.xscaler.preflight-request.v1';
const XSCALER_PREFLIGHT_RESPONSE_SCHEMA = 'xtend.xscaler.preflight-response.v1';
const XSCALER_REMOTE_SURFACE_PLAN_SCHEMA = 'xtend.xscaler.remote-surface-plan.v1';
const XSCALER_XTENSION_DEPLOYMENT_SCHEMA = 'xtend.xscaler.xtension-deployment.v1';
const XSCALER_ATC_HANDOFF_SCHEMA = 'xtend.xscaler.atc-handoff.v1';
const XSCALER_PROTOCOL = 'xscaler';

const XSCALER_ORIGIN_BLOCKED_CODE = 'xscaler.preflight.origin_blocked';
const XSCALER_INTEGRITY_MISSING_CODE = 'xscaler.preflight.integrity_missing';
const XSCALER_SSR_NETWORK_DENIED_CODE = 'xscaler.preflight.ssr_network_denied';
const XSCALER_FALLBACK_MISSING_CODE = 'xscaler.preflight.fallback_missing';
const XSCALER_XTENSION_DENIED_CODE = 'xscaler.preflight.xtension_denied';
const XSCALER_CAPABILITY_MISMATCH_CODE = 'xscaler.preflight.capability_mismatch';

function toArray(value) {
  if (Array.isArray(value)) return value;
  if (value === null || value === undefined) return [];
  return [value];
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function normalizeString(value, fallback = '') {
  if (typeof value === 'string') return value.trim() || fallback;
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  return fallback;
}

function cloneJson(value, fallback = null) {
  if (value === undefined || value === null) return fallback;
  return JSON.parse(JSON.stringify(value));
}

function normalizeCapabilities(value) {
  return toArray(value).map((capability) => {
    if (typeof capability === 'string') return normalizeString(capability);
    if (isPlainObject(capability)) return normalizeString(capability.id || capability.name || capability.capability);
    return '';
  }).filter(Boolean);
}

function diagnostic(code, message, severity = 'error', extra = {}) {
  return {
    code,
    severity,
    message,
    ...extra
  };
}

function firstRemoteSurface(remoteManifest) {
  if (!remoteManifest || typeof remoteManifest !== 'object') return null;
  if (remoteManifest.remoteSurface) return remoteManifest.remoteSurface;
  if (Array.isArray(remoteManifest.remoteSurfaces)) return remoteManifest.remoteSurfaces[0] || null;
  if (remoteManifest.schema === 'xtend.rmt.vnext-remote-surface.v1') return remoteManifest;
  return null;
}

function surfaceName(source = {}) {
  return normalizeString(source.surface || source.name || source.surfaceId || source.rmtSurface || source.id, 'checkout.cart')
    .replace(/^remoteSurface:/u, '');
}

function surfaceId(source = {}) {
  const id = normalizeString(source.surfaceId || source.rmtSurface || source.surface || source.name || source.id, 'checkout.cart');
  return id.startsWith('remoteSurface:') ? id : id;
}

function normalizeIntegrity(source = {}) {
  const integrity = source.integrity || source.remote && source.remote.integrity || {};
  if (typeof integrity === 'string') {
    const algorithm = integrity.split('-')[0] || 'sha256';
    return { algorithm, digest: integrity };
  }
  if (isPlainObject(integrity)) {
    return {
      algorithm: normalizeString(integrity.algorithm, 'sha256'),
      digest: normalizeString(integrity.digest || integrity.hash, '')
    };
  }
  return { algorithm: '', digest: '' };
}

function normalizeFallback(source = {}) {
  const fallback = source.fallbackSurface || source.fallback || source.fallbackRef || null;
  if (typeof fallback === 'string') return fallback;
  if (isPlainObject(fallback)) return normalizeString(fallback.ref || fallback.id || fallback.name, '');
  return '';
}

function normalizeLanes(source = {}) {
  const lanes = toArray(source.lanes || source.shellBindings || source.exposes);
  return lanes.length > 0
    ? lanes.map((entry) => {
      if (typeof entry === 'string') return { lane: 'default', target: entry };
      const target = isPlainObject(entry.target) ? entry.target.ref || entry.target.id : entry.target;
      return {
        lane: normalizeString(entry.lane || entry.name, 'default'),
        target: normalizeString(target || entry.ref || entry.id, 'shell.slot:default')
      };
    })
    : [{ lane: 'default', target: 'shell.slot:default' }];
}

function createXScalerPreflightRequest(input = {}) {
  const capabilities = normalizeCapabilities(input.capabilities || [
    'remote-surface-plan',
    'ssr-compatible',
    'xtension-deployment'
  ]);
  return {
    schema: XSCALER_PREFLIGHT_REQUEST_SCHEMA,
    protocol: XSCALER_PROTOCOL,
    requestId: normalizeString(input.requestId, 'xscaler-preflight-001'),
    surface: surfaceName(input),
    host: cloneJson(input.host, {
      runtime: 'xtend-rmt',
      ssr: true,
      xtensions: []
    }),
    capabilities,
    constraints: cloneJson(input.constraints, {
      allowNetworkDuringSsr: false
    })
  };
}

function createXScalerRemoteSurfacePlan(input = {}) {
  const source = firstRemoteSurface(input.remoteManifest)
    || input.remoteSurface
    || (isPlainObject(input.surface) ? input.surface : null)
    || input;
  const remote = source.remote || {};
  const integrity = normalizeIntegrity(source);
  const fallbackSurface = normalizeFallback(source);
  return {
    schema: XSCALER_REMOTE_SURFACE_PLAN_SCHEMA,
    protocol: XSCALER_PROTOCOL,
    surface: surfaceName(source),
    surfaceId: normalizeString(source.surfaceId || source.id, ''),
    owner: typeof source.owner === 'string'
      ? source.owner
      : normalizeString(source.owner && (source.owner.id || source.owner.name), 'unknown-owner'),
    origin: normalizeString(source.origin || remote.origin, ''),
    integrity,
    fallbackSurface,
    lanes: normalizeLanes(source),
    ssr: {
      mode: normalizeString(source.ssr && source.ssr.mode, 'preflight-only'),
      networkDuringRender: Boolean(source.ssr && source.ssr.networkDuringRender === true)
    },
    runtimeBoundary: {
      remoteRuntimeExecution: false,
      kernelRemoteExecution: false,
      networkRequiredByKernel: false
    }
  };
}

function createXScalerXtensionDeployment(input = {}) {
  const accepted = input.accepted !== false && input.ok !== false;
  return {
    schema: XSCALER_XTENSION_DEPLOYMENT_SCHEMA,
    protocol: XSCALER_PROTOCOL,
    deploymentId: normalizeString(input.deploymentId, 'xscaler-xtension-deployment'),
    xtension: normalizeString(input.xtension, 'host-controller'),
    surface: surfaceName(input),
    remoteSurfacePlan: normalizeString(input.remoteSurfacePlan, 'xscaler-remote-surface-plan.json'),
    rollout: cloneJson(input.rollout, { strategy: 'gated', percent: accepted ? 100 : 0 }),
    ssr: {
      hydrateAfterPreflight: input.ssr && input.ssr.hydrateAfterPreflight === false ? false : true,
      requiresDom: Boolean(input.ssr && input.ssr.requiresDom === true)
    },
    accepted
  };
}

function createXScalerAtcHandoff(input = {}) {
  const status = normalizeString(input.status, input.accepted === false || input.ok === false ? 'refused' : 'ready');
  const accepted = status !== 'refused' && input.accepted !== false && input.ok !== false;
  const signal = normalizeString(input.handoffSignal || input.action, accepted ? 'attach' : 'refuse');
  const lifecycleState = normalizeString(input.lifecycleState || input.state, signal);
  const normalizedSurfaceId = normalizeString(input.surfaceId || input.surface, 'remoteSurface:unknown');
  return {
    schema: XSCALER_ATC_HANDOFF_SCHEMA,
    protocol: XSCALER_PROTOCOL,
    surfaceId: normalizedSurfaceId,
    sessionId: normalizeString(input.sessionId, `xscaler:${normalizedSurfaceId}`),
    handoffSignal: signal,
    lifecycleState,
    accepted,
    ok: accepted,
    status: accepted ? status : 'refused',
    fallback: cloneJson(input.fallback || null, null),
    runtimeBoundary: {
      remoteRuntimeExecution: false,
      kernelRemoteExecution: false,
      networkRequiredByHandoff: false
    },
    diagnostics: toArray(input.diagnostics).map((entry) => cloneJson(entry, {}))
  };
}

function createXScalerPreflightResponse(input = {}) {
  const accepted = input.accepted !== undefined ? input.accepted === true : input.ok !== false;
  const diagnostics = toArray(input.diagnostics).map((entry) => cloneJson(entry, {}));
  const rejection = accepted ? null : cloneJson(input.rejection, {
    code: diagnostics[0] && diagnostics[0].code || XSCALER_CAPABILITY_MISMATCH_CODE,
    message: diagnostics[0] && diagnostics[0].message || 'XScaler preflight rejected the remote surface plan.'
  });
  return {
    schema: XSCALER_PREFLIGHT_RESPONSE_SCHEMA,
    protocol: XSCALER_PROTOCOL,
    requestId: normalizeString(input.requestId, 'xscaler-preflight-001'),
    accepted,
    ok: accepted,
    surface: surfaceName(input),
    compatibility: cloneJson(input.compatibility, {
      ssr: accepted ? 'compatible' : 'blocked',
      remoteSurfacePlan: accepted ? 'required' : 'blocked',
      xtensionDeployment: accepted ? 'allowed' : 'blocked'
    }),
    requiredAnchors: toArray(input.requiredAnchors).length > 0
      ? toArray(input.requiredAnchors).map((entry) => normalizeString(entry)).filter(Boolean)
      : ['#schemas', '#ssr-kompatibilitaet', '#xtensions-deployment'],
    remoteSurfacePlan: cloneJson(input.remoteSurfacePlan || null, null),
    atc: input.atc ? cloneJson(input.atc, null) : createXScalerAtcHandoff({
      surfaceId: input.surfaceId || input.surface,
      accepted,
      diagnostics
    }),
    rejection,
    diagnostics
  };
}

function hasCapability(request, capability) {
  return normalizeCapabilities(request && request.capabilities).includes(capability);
}

function hostAllowsOrigin(hostCapabilities, origin) {
  const allowed = toArray(hostCapabilities && (hostCapabilities.allowedOrigins || hostCapabilities.origins)).map(normalizeString).filter(Boolean);
  return allowed.includes(origin);
}

function reportHasBlockingDiagnostic(report) {
  return toArray(report && report.diagnostics).some((entry) => entry && (entry.severity === 'error' || entry.status === 'blocked'));
}

function evaluateXScalerPreflight(input = {}) {
  const request = createXScalerPreflightRequest(input.request || {});
  const plan = createXScalerRemoteSurfacePlan(input.remoteSurfacePlan || {
    remoteManifest: input.remoteManifest
  });
  const diagnostics = [];
  const hostCapabilities = input.hostCapabilities || {};
  const constraints = request.constraints || {};

  if (!hostAllowsOrigin(hostCapabilities, plan.origin)) {
    diagnostics.push(diagnostic(
      XSCALER_ORIGIN_BLOCKED_CODE,
      `Remote origin "${plan.origin || 'unknown'}" is not allowed by host capabilities.`,
      'error',
      { origin: plan.origin }
    ));
  }
  if (!plan.integrity || !plan.integrity.digest) {
    diagnostics.push(diagnostic(
      XSCALER_INTEGRITY_MISSING_CODE,
      'Remote surface plan is missing integrity metadata.'
    ));
  }
  if (constraints.allowNetworkDuringSsr === false && plan.ssr && plan.ssr.networkDuringRender === true) {
    diagnostics.push(diagnostic(
      XSCALER_SSR_NETWORK_DENIED_CODE,
      'Remote surface plan requested network access during SSR render.'
    ));
  }
  if (!plan.fallbackSurface) {
    diagnostics.push(diagnostic(
      XSCALER_FALLBACK_MISSING_CODE,
      'Remote surface plan is missing a fallback surface.'
    ));
  }
  if (hasCapability(request, 'xtension-deployment') && hostCapabilities.allowXtensionDeployment === false) {
    diagnostics.push(diagnostic(
      XSCALER_XTENSION_DENIED_CODE,
      'Host capabilities deny XTension deployment for this surface.'
    ));
  }
  if (hasCapability(request, 'remote-surface-plan') === false) {
    diagnostics.push(diagnostic(
      XSCALER_CAPABILITY_MISMATCH_CODE,
      'Preflight request did not ask for the remote-surface-plan capability.'
    ));
  }
  if (reportHasBlockingDiagnostic(input.remoteSecurityReport)) {
    diagnostics.push(diagnostic(
      XSCALER_ORIGIN_BLOCKED_CODE,
      'Remote security report contains blocking diagnostics.'
    ));
  }
  if (reportHasBlockingDiagnostic(input.degradationReport)) {
    diagnostics.push(diagnostic(
      XSCALER_FALLBACK_MISSING_CODE,
      'Degradation report contains blocking diagnostics.'
    ));
  }

  const accepted = diagnostics.length === 0;
  return createXScalerPreflightResponse({
    requestId: request.requestId,
    surface: request.surface,
    surfaceId: surfaceId(plan),
    accepted,
    remoteSurfacePlan: plan,
    diagnostics,
    rejection: accepted ? null : {
      code: diagnostics[0].code,
      message: diagnostics[0].message
    }
  });
}

module.exports = {
  XSCALER_ATC_HANDOFF_SCHEMA,
  XSCALER_CAPABILITY_MISMATCH_CODE,
  XSCALER_FALLBACK_MISSING_CODE,
  XSCALER_INTEGRITY_MISSING_CODE,
  XSCALER_ORIGIN_BLOCKED_CODE,
  XSCALER_PREFLIGHT_REQUEST_SCHEMA,
  XSCALER_PREFLIGHT_RESPONSE_SCHEMA,
  XSCALER_PROTOCOL,
  XSCALER_REMOTE_SURFACE_PLAN_SCHEMA,
  XSCALER_SSR_NETWORK_DENIED_CODE,
  XSCALER_XTENSION_DENIED_CODE,
  XSCALER_XTENSION_DEPLOYMENT_SCHEMA,
  createXScalerAtcHandoff,
  createXScalerPreflightRequest,
  createXScalerPreflightResponse,
  createXScalerRemoteSurfacePlan,
  createXScalerXtensionDeployment,
  evaluateXScalerPreflight
};
